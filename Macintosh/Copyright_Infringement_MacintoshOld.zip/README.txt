Copyright Infringement for MacOS (System 1 - MacOS 9)
=======================================================

This is a port of Copyright Infringement The Regressive right for older MacOS based systems.

Rikuto has trapped you in one of his sick games once again and this time, he paired you with another mate !
Follow the onscreen instructions to get more points !

Mac specifics
==================

You can run this from a hard drive or run this from the floppy disk image.
You can either burn the floppy disk image to a real floppy (double density floppy) or use a GOTEK.

Note that you will need at least 384kb free RAM available for the CI_Right_512KMac.dsk version, 
640kb for the Copyright_Infringement_Macintosh_System1_8.dsk version and 4MB of free RAM for the PowerPC version.

On an emulator like mini vmac, you can simply have System 1 in the first floppy slot and the game on the second one.
With macintosh.js, you can also place the game in the macintosh.js folder (On Linux, it's at $HOME) and it will mount it.

Changelog
=========

version 1.0 : 
Initial version with no PCM sound
